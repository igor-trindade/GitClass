package school.sptech.especialistas;

import school.sptech.Desenvolvedor;

public class DesenvolvedorMobile extends Desenvolvedor {

    private String plataforma ;
    private String linguagem;
    private Integer horasPrototipacao;
    private Double valorHrPrototip = 200.00;

    public DesenvolvedorMobile(){

    }

    public DesenvolvedorMobile(String nome, Integer qtdHoras, Double valorHora, Integer horasPrototipacao,
                               String linguagem, String plataforma, Double valorHrPrototip) {
        super(nome, qtdHoras, valorHora);
        this.horasPrototipacao = horasPrototipacao;
        this.linguagem = linguagem;
        this.plataforma = plataforma;
        this.valorHrPrototip = valorHrPrototip;
    }

    @Override
    public Double calcularSalario(){
        return super.calcularSalario() + (horasPrototipacao * valorHrPrototip);
    }

    public Integer getHorasPrototipacao() {
        return horasPrototipacao;
    }
    public void setHorasPrototipacao(Integer horasPrototipacao) {
        this.horasPrototipacao = horasPrototipacao;
    }
    public String getLinguagem() {
        return linguagem;
    }
    public void setLinguagem(String linguagem) {
        this.linguagem = linguagem;
    }
    public String getPlataforma() {
        return plataforma;
    }
    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }
    public Double getValorHrPrototip() {
        return valorHrPrototip;
    }
    public void setValorHrPrototip(Double valorHrPrototip) {
        this.valorHrPrototip = valorHrPrototip;
    }
}
