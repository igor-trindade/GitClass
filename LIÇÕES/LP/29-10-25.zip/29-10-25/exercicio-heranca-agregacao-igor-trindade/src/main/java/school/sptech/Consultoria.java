package school.sptech;
import school.sptech.especialistas.DesenvolvedorMobile;
import school.sptech.especialistas.DesenvolvedorWeb;
import java.util.ArrayList;
import java.util.List;

public class Consultoria {
    private String nome;
    private Integer vagas;
    private List<Desenvolvedor> devs = new ArrayList<>();

    public void contratar(DesenvolvedorWeb dev){
        if(vagas > devs.size()){
        devs.add(dev);
        }
    }

    public void contratarFullstack(DesenvolvedorWeb devWeb){
      if(devWeb.isFullstack()){
          devs.add(devWeb);
      }

    }

    public Double getTotalSalarios(){
        Double total = 0.0;
        for(Desenvolvedor d : devs){
          total +=  d.calcularSalario();
        }
        return total;
    }

    public Integer qtdDesenvolvedoresMobile(){
        Integer total = 0;
        for(Desenvolvedor d : devs){
            if (d.getClass() == DesenvolvedorMobile.class){
            total ++;
            }
        }
        return total;
    }

    public List<Desenvolvedor> buscarPorSalarioMaiorIgualQue(Double salario){
        List<Desenvolvedor> totalMaior = new ArrayList<>();

        for(Desenvolvedor d : devs){
           if(d.calcularSalario() >= salario){
               totalMaior.add(d);
           }
        }
        return  totalMaior;
    }

    public Desenvolvedor buscarMenorSalario(){
        Desenvolvedor devMenorSalario = devs.get(0);

        for (Desenvolvedor d : devs){
           if(d.calcularSalario() < devMenorSalario.calcularSalario()){
               devMenorSalario = d;
           }
        }
        return devMenorSalario;
    }

    public List<Desenvolvedor> buscarPorTecnologia(String tecnologia) {
        List<Desenvolvedor> resultado = new ArrayList<>();

        for (Desenvolvedor d : devs) {

            if (d instanceof DesenvolvedorWeb) {
                DesenvolvedorWeb w = (DesenvolvedorWeb) d;

                if ((w.getBackend() != null && w.getBackend().equalsIgnoreCase(tecnologia))
                        || (w.getFrontend() != null && w.getFrontend().equalsIgnoreCase(tecnologia))
                        || (w.getSgdb() != null && w.getSgdb().equalsIgnoreCase(tecnologia))) {
                    resultado.add(w);
                }
            }

            if (d instanceof DesenvolvedorMobile) {
                DesenvolvedorMobile m = (DesenvolvedorMobile) d;

                if ((m.getPlataforma() != null && m.getPlataforma().equalsIgnoreCase(tecnologia))
                        || (m.getLinguagem() != null && m.getLinguagem().equalsIgnoreCase(tecnologia))) {
                    resultado.add(m);
                }
            }
        }

        return resultado;
    }

    public Double getTotalSalariosPorTecnologia(String tecnologia) {
        double total = 0;

        for (Desenvolvedor d : devs) {

            if (d instanceof DesenvolvedorWeb) {
                DesenvolvedorWeb w = (DesenvolvedorWeb) d;

                if ((w.getBackend() != null && w.getBackend().equalsIgnoreCase(tecnologia))
                        || (w.getFrontend() != null && w.getFrontend().equalsIgnoreCase(tecnologia))
                        || (w.getSgdb() != null && w.getSgdb().equalsIgnoreCase(tecnologia))) {
                    total += w.calcularSalario();
                }
            }

            if (d instanceof DesenvolvedorMobile) {
                DesenvolvedorMobile m = (DesenvolvedorMobile) d;

                if ((m.getPlataforma() != null && m.getPlataforma().equalsIgnoreCase(tecnologia))
                        || (m.getLinguagem() != null && m.getLinguagem().equalsIgnoreCase(tecnologia))) {
                    total += m.calcularSalario();
                }
            }
        }

        return total;
    }


}