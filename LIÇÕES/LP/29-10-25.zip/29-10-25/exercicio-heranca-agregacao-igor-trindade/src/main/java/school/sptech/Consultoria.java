package school.sptech;

import school.sptech.especialistas.DesenvolvedorMobile;
import school.sptech.especialistas.DesenvolvedorWeb;
import java.util.ArrayList;
import java.util.List;

public class Consultoria {
    private String nome;
    private Integer vagas;
    private List<Desenvolvedor> desenvolvedores = new ArrayList<>();

    public void contratar(Desenvolvedor dev) {
        if (vagas != null && desenvolvedores.size() < vagas) {
            desenvolvedores.add(dev);
        }
    }

    public void contratarFullstack(DesenvolvedorWeb devWeb) {
        if (devWeb.isFullstack() && vagas != null && desenvolvedores.size() < vagas) {
            desenvolvedores.add(devWeb);
        }
    }

    public Double getTotalSalarios() {
        Double total = 0.0;
        for (Desenvolvedor d : desenvolvedores) {
            total += d.calcularSalario();
        }
        return total;
    }

    public Integer qtdDesenvolvedoresMobile() {
        Integer total = 0;
        for (Desenvolvedor d : desenvolvedores) {
            if (d instanceof DesenvolvedorMobile) {
                total++;
            }
        }
        return total;
    }

    public List<Desenvolvedor> buscarPorSalarioMaiorIgualQue(Double salario) {
        List<Desenvolvedor> totalMaior = new ArrayList<>();
        for (Desenvolvedor d : desenvolvedores) {
            if (d.calcularSalario() >= salario) {
                totalMaior.add(d);
            }
        }
        return totalMaior;
    }

    public Desenvolvedor buscarMenorSalario() {
        if (desenvolvedores.isEmpty()) return null;

        Desenvolvedor devMenorSalario = desenvolvedores.get(0);
        for (Desenvolvedor d : desenvolvedores) {
            if (d.calcularSalario() < devMenorSalario.calcularSalario()) {
                devMenorSalario = d;
            }
        }
        return devMenorSalario;
    }

    public List<Desenvolvedor> buscarPorTecnologia(String tecnologia) {
        List<Desenvolvedor> resultado = new ArrayList<>();

        for (Desenvolvedor d : desenvolvedores) {

            if (d instanceof DesenvolvedorWeb) {
                DesenvolvedorWeb w = (DesenvolvedorWeb) d;

                if ((w.getBackend() != null && w.getBackend().equalsIgnoreCase(tecnologia))
                        || (w.getFrontend() != null && w.getFrontend().equalsIgnoreCase(tecnologia))
                        || (w.getSgbd() != null && w.getSgbd().equalsIgnoreCase(tecnologia))) {
                    resultado.add(w);
                }
            }

            if (d instanceof DesenvolvedorMobile) {
                DesenvolvedorMobile m = (DesenvolvedorMobile) d;

                if ((m.getPlataforma() != null && m.getPlataforma().equalsIgnoreCase(tecnologia))
                        || (m.getLinguagem() != null && m.getLinguagem().equalsIgnoreCase(tecnologia))) {
                    resultado.add(m);
                }
            }
        }

        return resultado;
    }

    public Double getTotalSalariosPorTecnologia(String tecnologia) {
        double total = 0;

        for (Desenvolvedor d : desenvolvedores) {

            if (d instanceof DesenvolvedorWeb) {
                DesenvolvedorWeb w = (DesenvolvedorWeb) d;

                if ((w.getBackend() != null && w.getBackend().equalsIgnoreCase(tecnologia))
                        || (w.getFrontend() != null && w.getFrontend().equalsIgnoreCase(tecnologia))
                        || (w.getSgbd() != null && w.getSgbd().equalsIgnoreCase(tecnologia))) {
                    total += w.calcularSalario();
                }
            }

            if (d instanceof DesenvolvedorMobile) {
                DesenvolvedorMobile m = (DesenvolvedorMobile) d;

                if ((m.getPlataforma() != null && m.getPlataforma().equalsIgnoreCase(tecnologia))
                        || (m.getLinguagem() != null && m.getLinguagem().equalsIgnoreCase(tecnologia))) {
                    total += m.calcularSalario();
                }
            }
        }

        return total;
    }



    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public List<Desenvolvedor> getDesenvolvedores() {
        return desenvolvedores;
    }

    public void setDesenvolvedores(List<Desenvolvedor> desenvolvedores) {
        this.desenvolvedores = desenvolvedores;
    }
}
