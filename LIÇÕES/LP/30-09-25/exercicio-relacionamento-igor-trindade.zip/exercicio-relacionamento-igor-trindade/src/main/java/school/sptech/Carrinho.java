package school.sptech;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    private String cliente;
    private List<Produto> carrinho = new ArrayList<>();

    public String getCliente() {
        return this.cliente;
    }

    public void adicionar(Produto produto){
        this.carrinho.add(produto);
    }

    public Boolean existsPorNome(String nome){
        for (int i = 0 ; i <= carrinho.toArray().length;i++){
            Boolean tem = false;

        }

    }
}
